from pyspark.sql.functions import concat, count, col
from pyspark.sql.window import Window

class transformations:
    def dedup(
        self,
        df,
        df_dedup_cols: list,
        cdc: str
    ):
        df = df.withColumn(
            "dedupKey",
            concat(*[col(c) for c in df_dedup_cols])
        )
        window_spec = Window.partitionBy("dedupKey").orderBy(col(cdc).desc())
        df = df.withColumn(
            "dedupCounts",
            count("dedupKey").over(window_spec)
        )
        df = df.filter(col("dedupCounts") == 1)
        return df