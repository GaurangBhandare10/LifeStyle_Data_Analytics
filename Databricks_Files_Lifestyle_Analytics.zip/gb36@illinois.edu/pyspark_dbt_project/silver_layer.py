# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import concat, count, col
from pyspark.sql.window import Window


# COMMAND ----------

import os
import sys

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

curr_dir = os.getcwd()
print(curr_dir)
sys.path.append(curr_dir)

# COMMAND ----------

df_cust = spark.read.table("pysparkdbt.bronze.customers")

# COMMAND ----------

display(df_cust.count())


# COMMAND ----------

df_cust = df_cust.withColumn("email_domain", split(col('email'),"@")[1])
display(df_cust)

# COMMAND ----------

df_cust = df_cust.withColumn("phone_number", regexp_replace("phone_number",r"[^0-9]",""))
display(df_cust)

# COMMAND ----------

df_cust= df_cust.withColumn("full_name",concat_ws(" ",col("first_name"),col("last_name")))
display(df_cust)


# COMMAND ----------

class transformations:
    def dedup(
        self,
        df,
        df_dedup_cols: list,
        cdc: str
    ):
        df = df.withColumn(
            "dedupKey",
            concat(*[col(c) for c in df_dedup_cols])
        )
        window_spec = Window.partitionBy("dedupKey").orderBy(col(cdc).desc())
        df = df.withColumn(
            "dedupCounts",
            count("dedupKey").over(window_spec)
        )
        df = df.filter(col("dedupCounts") == 1)
        return df

# COMMAND ----------

# from utils.custom_utils import transformations
cust_obj = transformations()
df_cust_transform = cust_obj.dedup(df_cust, ['customer_id'], 'last_updated_timestamp')
display(df_cust_transform)

# COMMAND ----------

