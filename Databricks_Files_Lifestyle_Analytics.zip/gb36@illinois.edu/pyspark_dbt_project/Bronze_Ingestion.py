# Databricks notebook source
# MAGIC %md
# MAGIC ## **SPARK STEAMING**

# COMMAND ----------

entities = ['customers', 'trips', 'locations', 'payments', 'vehicles', 'drivers']

# COMMAND ----------

for entity in entities:

    df_batch = spark.read.format("csv")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load(f"/Volumes/pysparkdbt/source/source_data/{entity}/")

    schema_entity = df_batch.schema
    schema_entity


    df = spark.readStream.format("csv")\
        .option("header", "true")\
        .schema(schema_entity)\
        .load(f"/Volumes/pysparkdbt/source/source_data/{entity}/")

    df.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation", f"/Volumes/pysparkdbt/source/source_data/{entity}")\
        .trigger(once=True)\
        .toTable(f"pysparkdbt.bronze.{entity}")


# COMMAND ----------


