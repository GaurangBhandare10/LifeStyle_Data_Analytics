# Databricks notebook source

from pyspark.sql.functions import col, when
from pyspark.sql import SparkSession
import re

# COMMAND ----------

df = spark.read.table("dwbi_project.bronze.lifestyle_bronze")

# COMMAND ----------

df = df.withColumn(
    "weight_category",
    when(col("bmi") < 18.5, "Underweight")
    .when((col("bmi") >= 18.5) & (col("bmi") <= 24.99), "Healthy Weight")
    .when((col("bmi") >= 25.0) & (col("bmi") <= 29.99), "Overweight")
    .when((col("bmi") >= 30.0) & (col("bmi") < 40.0), "Obesity")
    .when(col("bmi") >= 40.0, "Severe Obesity")
    .otherwise("Unknown")
)

# COMMAND ----------

df.display()

# COMMAND ----------

from pyspark.sql.functions import col, when

df = df.withColumn(
    "activity_level",
    when(
        (col("`Workout_Frequency (days/week)`") <= 2),
        "Sedentary"
    )
    .when(
        (col("`Workout_Frequency (days/week)`") > 2) & 
        (col("`Workout_Frequency (days/week)`") <= 3),
        "Active"
    )
    .when(
        col("`Workout_Frequency (days/week)`") >= 3,
        "Highly Active"
    )
    .otherwise("Unknown")
)


# COMMAND ----------

# df = spark.sql("select * from dwbi_project.bronze.lifestyle_bronze")
df.display()                # shows first 20 rows


# COMMAND ----------


df = df.withColumn(
        "experience_category",
        when(col("Experience_Level") <= 1.99, "Beginner")
        .when(col("Experience_Level") <= 2.99, "Amateur")
        .otherwise("Advanced")
    )


# COMMAND ----------

df.display()

# COMMAND ----------


df = df.withColumn(
    "fitness_goal",
    when(col("Calories") > col("Calories_Burned"), "Gain")
    .otherwise("Cut")
)
df.display()

# COMMAND ----------

df.display()

# COMMAND ----------

# df = df.withColumn(
#     "age_range",
#     when((col("age") >= 11.99) & (col("age") <= 23.99), "Young Adult")
#     .when((col("age") >= 24) & (col("age") <= 33.99), "Early Adult")
#     .when((col("age") >= 34) & (col("age") <= 43.99), "Middle Adult")
#     .when((col("age") >= 44) & (col("age") <= 53.99), "Mature Adult")
#     .when((col("age") >= 54),"Senior Adult")
# )


# COMMAND ----------

df = df.withColumn(
    "age_range",
    when(col("age") < 25, "Young Adult")
    .when(col("age") < 35, "Early Adult")
    .when(col("age") < 45, "Middle Adult")
    .when(col("age") < 55, "Mature Adult")
    .otherwise("Senior Adult")
)

# COMMAND ----------

df.columns

# COMMAND ----------


def clean_column_name(col_name):
    # Lowercase the column
    new_col = col_name.lower()
    # Replace spaces with underscore
    new_col = new_col.replace(" ", "_")
    # Remove special characters except underscore
    new_col = re.sub(r'[^a-z0-9_]', '', new_col)
    return new_col

# Apply transformation to all column names
cleaned_cols = [col(c).alias(clean_column_name(c)) for c in df.columns]

df = df.select(*cleaned_cols)


# COMMAND ----------

df.display()

# COMMAND ----------


df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("dwbi_project.silver.t_lifestyle_silver")


# COMMAND ----------

spark.sql("create or replace view dwbi_project.silver.v_lifestyle_silver as select * from dwbi_project.silver.t_lifestyle_silver")