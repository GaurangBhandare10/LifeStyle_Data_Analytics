# Databricks notebook source
from pyspark.sql.functions import col, when
from pyspark.sql import SparkSession
import re

# COMMAND ----------

spark.sql("""CREATE OR REPLACE TABLE dwbi_project.gold.t_lifestyle_gold AS
    SELECT
activity_level,
age_range,
ROUND(age, 2) AS age,
ROUND(avg_bpm, 2) AS avg_bpm,
benefit,
ROUND(bmi, 2) AS bmi,
ROUND(bmi_calc, 2) AS bmi_calc,
body_part,
ROUND(burns_calories_per_30_min, 2) AS burns_calories_per_30_min,
burns_calories_bin,
ROUND(cal_balance, 2) AS cal_balance,
ROUND(cal_from_macros, 2) AS cal_from_macros,
ROUND(calories, 2) AS calories,
ROUND(calories_burned, 2) AS calories_burned,
ROUND(carbs, 2) AS carbs,
ROUND(cholesterol_mg, 2) AS cholesterol_mg,
ROUND(cook_time_min, 2) AS cook_time_min,
cooking_method,
ROUND(daily_meals_frequency, 2) AS daily_meals_frequency,
diet_type,
difficulty_level,
equipment_needed,
ROUND(experience_level, 2) AS experience_level,
experience_category,
ROUND(expected_burn, 2) AS expected_burn,
ROUND(fat_percentage, 2) AS fat_percentage,
ROUND(fats, 2) AS fats,
fitness_goal,
gender,
ROUND(height_m, 2) AS height_m,
ROUND(lean_mass_kg, 2) AS lean_mass_kg,
meal_name,
meal_type,
ROUND(max_bpm, 2) AS max_bpm,
name_of_exercise,
ROUND(pct_carbs, 2) AS pct_carbs,
ROUND(pct_hrr, 2) AS pct_hrr,
ROUND(pct_maxhr, 2) AS pct_maxhr,
ROUND(physical_exercise, 2) AS physical_exercise,
ROUND(prep_time_min, 2) AS prep_time_min,
ROUND(protein_per_kg, 2) AS protein_per_kg,
ROUND(proteins, 2) AS proteins,
ROUND(rating, 2) AS rating,
ROUND(reps, 2) AS reps,
ROUND(resting_bpm, 2) AS resting_bpm,
ROUND(sets, 2) AS sets,
ROUND(serving_size_g, 2) AS serving_size_g,
ROUND(session_duration_hours, 2) AS session_duration_hours,
ROUND(sodium_mg, 2) AS sodium_mg,
ROUND(sugar_g, 2) AS sugar_g,
target_muscle_group,
type_of_muscle,
ROUND(water_intake_liters, 2) AS water_intake_liters,
ROUND(weight_kg, 2) AS weight_kg,
weight_category,
workout,
ROUND(workout_frequency_daysweek, 2) AS workout_frequency_daysweek,
workout_type
FROM dwbi_project.silver.v_lifestyle_silver
where age >=11.99;
""")

# COMMAND ----------

spark.sql("""CREATE OR REPLACE VIEW dwbi_project.gold.v_lifestyle_gold AS
    SELECT * FROM dwbi_project.gold.t_lifestyle_gold;
""")